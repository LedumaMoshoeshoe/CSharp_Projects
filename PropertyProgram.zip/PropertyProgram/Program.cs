﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Welcome message
        Console.WriteLine("Welcome to the City Finder program.");

        // List of cities
        string[] cities = { "Butterworth", "Mthatha", "Jagersfontein", "Kroonstad", "Boksburg", "Soweto", "Empangeni", "Polokwane", "Secunda", "Kuruman" };

        // Display all cities
        Console.WriteLine("\nList of cities:");
        foreach (string city in cities)
        {
            Console.WriteLine(city);
        }

        // Prompt user to enter starting and ending characters
        Console.Write("\nEnter starting character for a city: ");
        char startChar = Console.ReadLine().FirstOrDefault();
        Console.Write("Enter ending character for a city: ");
        char endChar = Console.ReadLine().FirstOrDefault();

        // Find cities that start and end with specified characters
        var matchedCities = from city in cities
                            where city.StartsWith(startChar.ToString(), StringComparison.OrdinalIgnoreCase)
                            && city.EndsWith(endChar.ToString(), StringComparison.OrdinalIgnoreCase)
                            select city;

        // Display matched cities
        Console.WriteLine("\nCities that start with '{0}' and end with '{1}':", startChar, endChar);
        if (matchedCities.Any())
        {
            foreach (string city in matchedCities)
            {
                Console.WriteLine(city);
            }
        }
        else
        {
            Console.WriteLine("No matching cities found.");
        }

        // Wait for user to close console
        Console.WriteLine("\nPress any key to exit.");
        Console.ReadKey();
    }
}
