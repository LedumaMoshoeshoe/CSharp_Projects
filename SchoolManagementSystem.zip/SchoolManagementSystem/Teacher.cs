﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolManagementSystem
{
    public partial class Teacher : Form
    {
        public Teacher()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Insert into teacher values(@name,@age,@gender)", con);


            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));
            cnn.Parameters.AddWithValue("@Age", int.Parse(textBox2.Text));

            cnn.Parameters.AddWithValue("@Gender", (comboBox1.Text));





            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Saved");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from teacher", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Update teacher values set age=@age,gender=@gender where name=@name", con);

            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));

            cnn.Parameters.AddWithValue("@Age", int.Parse(textBox2.Text));

            cnn.Parameters.AddWithValue("@Gender", comboBox1.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Updated");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Delete teacher where name=@name", con);
            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));


            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Deleted");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from teacher", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;
        }
    }
}
