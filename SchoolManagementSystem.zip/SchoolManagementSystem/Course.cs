﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolManagementSystem
{
    public partial class Course : Form
    {
        public Course()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Insert into course values(@name,@course,@credit)", con);


            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));

            cnn.Parameters.AddWithValue("@Course", (textBox2.Text));

            cnn.Parameters.AddWithValue("@Credit", int.Parse(textBox3.Text));



            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Saved");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from course", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Update course values set course=@course,credit=@credit where name=@name", con);

            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));

            cnn.Parameters.AddWithValue("@Course", (textBox2.Text));

            cnn.Parameters.AddWithValue("@Credit", int.Parse(textBox3.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Updated");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Delete course where name=@name", con);
            cnn.Parameters.AddWithValue("@Name", (textBox1.Text));


            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Deleted");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from course", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;
        }
    }
}
