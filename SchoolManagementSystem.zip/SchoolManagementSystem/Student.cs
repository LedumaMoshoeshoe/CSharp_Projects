﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystem
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Insert into Student values(@id,@name,@roll@email address,@phone)", con);

            cnn.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));

            cnn.Parameters.AddWithValue("@Name", int.Parse(textBox2.Text));

            cnn.Parameters.AddWithValue("@Roll", int.Parse(textBox3.Text));

            cnn.Parameters.AddWithValue("@Email Address", (textBox4.Text));

            cnn.Parameters.AddWithValue("@Phone", (textBox5.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Saved");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from Student", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Update Student values set name=@name,roll=@roll,email=@email address,phone=@phone where id=@id", con);

            cnn.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));

            cnn.Parameters.AddWithValue("@Name", int.Parse(textBox2.Text));

            cnn.Parameters.AddWithValue("@Roll", int.Parse(textBox3.Text));

            cnn.Parameters.AddWithValue("@Email Address", (textBox4.Text));

            cnn.Parameters.AddWithValue("@Phone", (textBox5.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Updated");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            con.Open();

            SqlCommand cnn = new SqlCommand("Delete Student where id=@id", con);



            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Data Deleted");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=Data Source=DESKTOP-DIFTE2T;Initial Catalog=SchoolManagementSystemm;Integrated Security=True");

            SqlCommand cnn = new SqlCommand("Select * from Student", con);

            SqlDataAdapter da = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            da.Fill(table);

            dataGridView1.DataSource = table;
        }
    }
}
