﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolManagementSystemV2
{
    public partial class Login : Form
    {
        SqlCommand cmd;
        SqlConnection conn;
        SqlDataReader rdr;
        public Login()
        {
            InitializeComponent();
            PassLog.PasswordChar = '*';
        }
        private void Login_Load(object sender, EventArgs e)
        {

            
            conn.Open();

        }

        private void Show_pass_CheckedChanged_1(object sender, EventArgs e)
        {
            if (Show_pass.Checked)
            {
                PassLog.PasswordChar = '\0';
            }
            else
